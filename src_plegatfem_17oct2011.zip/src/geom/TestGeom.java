/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package geom;

import gui.PlegatFemGui;
import plegatfem.Material;

/**
 *
 * @author jmb2
 */
public class TestGeom {
    
    public static void main(String[] args) {
        
        GeoPoint p1=new GeoPoint("1", 10, 10);
        GeoPoint p2=new GeoPoint("2", 100, 10);
        GeoPoint p3=new GeoPoint("3", 100, 100);
        GeoPoint p4=new GeoPoint("4", 10, 100);
        
        Material mat=new Material("alu", 70000, 0.33);
        
        GeoQuad quad=new GeoQuad("1", p1, p2, p3, p4, 1, mat);
        quad.mesh(10, 1, 1);
        
        PlegatFemGui gui=new PlegatFemGui();
        gui.setVisible(true);
        
        
        
    }
    
    
}
