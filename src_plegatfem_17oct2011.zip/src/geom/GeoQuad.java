/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package geom;

import java.util.ArrayList;
import plegatfem.Beam;
import plegatfem.Material;
import plegatfem.Node;
import plegatfem.Tri;

/**
 *
 * @author jmb2
 */
public class GeoQuad {

    private String id;
    private GeoPoint p1, p2, p3, p4;
    private double thickness;
    private ArrayList<Node> nodes;
    private ArrayList<Tri> tris;
    private Material mat;

    public GeoQuad(String id, GeoPoint p1, GeoPoint p2, GeoPoint p3, GeoPoint p4, double thickness, Material mat) {
        this.id = id;
        this.p1 = p1;
        this.p2 = p2;
        this.p3 = p3;
        this.p4 = p4;
        this.thickness = thickness;
        this.mat = mat;

        this.nodes = new ArrayList<Node>();
        this.tris = new ArrayList<Tri>();

        this.init();
    }

    public final void init() {
        this.nodes.clear();
        this.tris.clear();
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public GeoPoint getP1() {
        return p1;
    }

    public void setP1(GeoPoint p1) {
        this.p1 = p1;
    }

    public GeoPoint getP2() {
        return p2;
    }

    public void setP2(GeoPoint p2) {
        this.p2 = p2;
    }

    public GeoPoint getP3() {
        return p3;
    }

    public void setP3(GeoPoint p3) {
        this.p3 = p3;
    }

    public GeoPoint getP4() {
        return p4;
    }

    public void setP4(GeoPoint p4) {
        this.p4 = p4;
    }

    public double getThickness() {
        return thickness;
    }

    public void setThickness(double thickness) {
        this.thickness = thickness;
    }

    public Material getMat() {
        return mat;
    }

    public void setMat(Material mat) {
        this.mat = mat;
    }

    public void mesh(double meshSize, int nodeId, int elementId) {

        double l1 = Math.sqrt(Math.pow(p2.getX() - p1.getX(), 2) + Math.pow(p2.getY() - p1.getY(), 2));
        double l2 = Math.sqrt(Math.pow(p3.getX() - p2.getX(), 2) + Math.pow(p3.getY() - p2.getY(), 2));
        double l3 = Math.sqrt(Math.pow(p4.getX() - p3.getX(), 2) + Math.pow(p4.getY() - p3.getY(), 2));
        double l4 = Math.sqrt(Math.pow(p1.getX() - p4.getX(), 2) + Math.pow(p1.getY() - p4.getY(), 2));

        int nbElements1 = (int) Math.round(Math.min(l1, l3) / meshSize) + 1;
        int nbElements2 = (int) Math.round(Math.min(l2, l4) / meshSize) + 1;

        double p1x = p1.getX();
        double p2x = p2.getX();
        double p3x = p3.getX();
        double p4x = p4.getX();
        double p1y = p1.getY();
        double p2y = p2.getY();
        double p3y = p3.getY();
        double p4y = p4.getY();



        for (int j = 0; j < (nbElements2 + 1); j++) {
            for (int i = 0; i < (nbElements1 + 1); i++) {

                double xNode0 = p1x + (p4x - p1x) / nbElements2 * j;
                double xNode1 = p2x + (p3x - p2x) / nbElements2 * j;

                double yNode0 = p1y + (p4y - p1y) / nbElements2 * j;
                double yNode1 = p2y + (p3y - p2y) / nbElements2 * j;

                double xNode = xNode0 + (xNode1 - xNode0) / nbElements1 * i;
                double yNode = yNode0 + (yNode1 - yNode0) / nbElements1 * i;

                this.nodes.add(new Node(String.valueOf(nodeId), xNode, yNode));
                System.out.println("node #" + nodeId + ": " + xNode + " / " + yNode);
                nodeId++;

            }
        }

        for (int i = 0; i < nbElements1; i++) {
            for (int j = 0; j < nbElements2; j++) {

                Node n1 = this.nodes.get(j * (nbElements1 + 1) + i);
                Node n2 = this.nodes.get(j * (nbElements1 + 1) + i + 1);
                Node n3 = this.nodes.get((j + 1) * (nbElements1 + 1) + i + 1);
                Node n4 = this.nodes.get((j + 1) * (nbElements1 + 1) + i);

                this.tris.add(new Tri(n1, n2, n3, thickness, mat, 0.0));
                this.tris.add(new Tri(n1, n3, n4, thickness, mat, 0.0));
            }
        }


    }

    public ArrayList<Tri> getTris() {
        return tris;
    }

    public ArrayList<Node> getNodes() {
        return nodes;
    }
}
